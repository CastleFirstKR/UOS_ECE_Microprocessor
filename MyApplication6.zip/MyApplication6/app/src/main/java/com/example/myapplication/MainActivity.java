package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.hardware.Camera;
import android.view.Surface;
import android.view.View;
import android.widget.*;
import android.widget.FrameLayout;
import android.hardware.Camera.PictureCallback;
import android.os.Bundle;

import org.w3c.dom.Text;


public class MainActivity extends AppCompatActivity {
    static{
        System.loadLibrary("OpenCLDriver");
    }
    private native static float find_seongwon(Bitmap bitmap);
    private native static int openDriver(String path);
    private native static void closeDriver();
    private native static void writeDriver(byte[] data, int length);
    byte[] bit_data= {0,0,0,0,0,0,0,0};

    public native Bitmap GaussianBlurCPU(Bitmap bitmap);
    public native Bitmap GaussianBlurGPU(Bitmap bitmap);
    public native Bitmap Gray_ScaleCPU(Bitmap bitmap);
    public native Bitmap Gray_scaleGPU(Bitmap bitmap);
    Bitmap buf_bitmap;
    private static final String TAG ="CamTestActivity";
    private Camera mCamera;
    private CameraPreivew mPreview;
    private ImageView capturedImageHolder;
    private float end,start;
    private float timesub;
    private String ts;

    final TextView tv = (TextView) findViewById(R.id.textView);


    protected  void onCreate(Bundle savedInstanceState) {
        //segment
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //camera and blur

        Button btn = (Button) findViewById(R.id.button_capture);
        Button btn2 = (Button) findViewById(R.id.button_capture2);
        Button btn3 = (Button) findViewById(R.id.button_capture3);
        Button btn4 = (Button) findViewById(R.id.button_capture4);
        Button btn5 = (Button) findViewById(R.id.button_capture5);
        Button btn6 = (Button) findViewById(R.id.button_capture6);

        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inPreferredConfig = Bitmap.Config.ARGB_8888;

        capturedImageHolder = (ImageView) findViewById(R.id.captured_image);
        mCamera = getCameraInstance();
        mCamera.setDisplayOrientation(180);

        mPreview = new CameraPreivew(this, mCamera);
        FrameLayout preview = (FrameLayout) findViewById(R.id.camera_preview);
        preview.addView(mPreview);

        // button click start

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                bit_data[0]=1;
                bit_data[1]=0;
                bit_data[2] =0;
                bit_data[3] =0;
                bit_data[4] =0;
                bit_data[5] =0;
                writeDriver(bit_data,bit_data.length);

                mCamera.takePicture(null, null, pictureCallback);

            }
        });
        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                bit_data[0]=0;
                bit_data[1]=1;
                bit_data[2] =0;
                bit_data[3] =0;
                bit_data[4] =0;
                bit_data[5] =0;

                writeDriver(bit_data,bit_data.length);

                mCamera.takePicture(null, null, pictureCallback2);

            }
        });

        btn3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                bit_data[0]=0;
                bit_data[1]=0;
                bit_data[2] =1;
                bit_data[3] =0;
                bit_data[4] =0;
                bit_data[5] =0;
                writeDriver(bit_data,bit_data.length);

                mCamera.takePicture(null,null,pictureCallback3);

            }
        });

        btn4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                bit_data[0]=0;
                bit_data[1]=0;
                bit_data[2] =0;
                bit_data[3] =1;
                bit_data[4] =0;
                bit_data[5] =0;
                writeDriver(bit_data,bit_data.length);
                mCamera.takePicture(null,null,pictureCallback4);
            }
        });

        btn5.setOnClickListener(new View.OnClickListener() { //piezo
            @Override
            public void onClick(View view) {
                bit_data[0]=0;
                bit_data[1]=0;
                bit_data[2] =0;
                bit_data[3] =0;
                bit_data[4] =1;
                bit_data[5] =0;
                writeDriver(bit_data,bit_data.length);
                mCamera.takePicture(null,null,pictureCallback3);
            }
        });

    }


    public static Camera getCameraInstance() {
        Camera c = null;
        try {
            c = Camera.open();
        }catch(Exception e){

        }
        return c;
    }

    PictureCallback pictureCallback = new PictureCallback() {
        @Override
        public void onPictureTaken(byte[] data, Camera camera) {
            BitmapFactory.Options options = new BitmapFactory.Options();
            options.inSampleSize = 2;
            Bitmap bitmap = BitmapFactory.decodeByteArray(data, 0, data.length,options);
            int w = bitmap.getWidth();
            int h = bitmap.getHeight();

            Matrix mtx = new Matrix();
            mtx.postRotate(180);
            Bitmap rotatedBitmap = Bitmap.createBitmap(bitmap, 0, 0, w, h, mtx, true);

            if (bitmap == null) {
                Toast.makeText(MainActivity.this, "Capture img is empty", Toast.LENGTH_LONG).show();
                return;
            }
            start = (float)System.nanoTime()/1000000;
            // captured image
            buf_bitmap = scaleDownBitmapImage(rotatedBitmap,300,300);
            end = (float)System.nanoTime()/1000000;

            timesub = end-start;
            ts= Float.toString(timesub);
            tv.setText("Execution Time: " + ts+ "ms");
            //captured image store
            capturedImageHolder.setImageBitmap(buf_bitmap);

        }
    };
    PictureCallback pictureCallback2 = new PictureCallback() {
        @Override
        public void onPictureTaken(byte[] data, Camera camera) {
            BitmapFactory.Options options = new BitmapFactory.Options();
            options.inSampleSize = 2;
            Bitmap bitmap = BitmapFactory.decodeByteArray(data, 0, data.length,options);


            int w = bitmap.getWidth();
            int h = bitmap.getHeight();

            Matrix mtx = new Matrix();
            mtx.postRotate(180);
            Bitmap rotatedBitmap = Bitmap.createBitmap(bitmap, 0, 0, w, h, mtx, true);


            if (bitmap == null) {
                Toast.makeText(MainActivity.this, "Capture img is empty", Toast.LENGTH_LONG).show();
                return;
            }
            // captured image
            buf_bitmap = scaleDownBitmapImage(rotatedBitmap,300,300);
            start = (float)System.nanoTime()/1000000;

            buf_bitmap = GaussianBlurCPU(buf_bitmap);

            end = (float)System.nanoTime()/1000000;
            timesub = end-start;
            ts = Float.toString(timesub);

            //captured image store
            capturedImageHolder.setImageBitmap(buf_bitmap);
            tv.setText("Execution Time: " + ts + "ms");

        }
    };

    PictureCallback pictureCallback3 = new PictureCallback() {
        @Override
        public void onPictureTaken(byte[] data, Camera camera) {
            BitmapFactory.Options options = new BitmapFactory.Options();
            options.inSampleSize = 2;
            Bitmap bitmap = BitmapFactory.decodeByteArray(data, 0, data.length,options);


            int w = bitmap.getWidth();
            int h = bitmap.getHeight();

            Matrix mtx = new Matrix();
            mtx.postRotate(180);
            Bitmap rotatedBitmap = Bitmap.createBitmap(bitmap, 0, 0, w, h, mtx, true);


            if (bitmap == null) {
                Toast.makeText(MainActivity.this, "Capture img is empty", Toast.LENGTH_LONG).show();
                return;
            }
            // captured image
            buf_bitmap = scaleDownBitmapImage(rotatedBitmap,300,300);

            start = (float)System.nanoTime()/1000000;
            buf_bitmap = GaussianBlurGPU(buf_bitmap);
            end = (float)System.nanoTime()/1000000;
            timesub = end-start;
            ts = Float.toString(timesub);
            //captured image store
            capturedImageHolder.setImageBitmap(buf_bitmap);
            tv.setText("Execution Time: " + ts + "ms");
        }
    };
    PictureCallback pictureCallback4 = new PictureCallback() {
        @Override
        public void onPictureTaken(byte[] data, Camera camera) {
            BitmapFactory.Options options = new BitmapFactory.Options();
            options.inSampleSize = 2;
            Bitmap bitmap = BitmapFactory.decodeByteArray(data, 0, data.length,options);


            int w = bitmap.getWidth();
            int h = bitmap.getHeight();

            Matrix mtx = new Matrix();
            mtx.postRotate(180);
            Bitmap rotatedBitmap = Bitmap.createBitmap(bitmap, 0, 0, w, h, mtx, true);


            if (bitmap == null) {
                Toast.makeText(MainActivity.this, "Capture img is empty", Toast.LENGTH_LONG).show();
                return;
            }
            // captured image
            buf_bitmap = scaleDownBitmapImage(rotatedBitmap,300,300);

            start = (float)System.nanoTime()/1000000;
            buf_bitmap = Gray_ScaleCPU(buf_bitmap);
            end = (float)System.nanoTime()/1000000;
            timesub = end-start;
            ts = Float.toString(timesub);
            //captured image store
            capturedImageHolder.setImageBitmap(buf_bitmap);
            tv.setText("Execution Time: " + ts + "ms");
        }
    };

    // segment


    private Bitmap scaleDownBitmapImage(Bitmap bitmap, int newWidth, int newHeight){
        Bitmap resizedBitmap= Bitmap.createScaledBitmap(bitmap, newWidth, newHeight,true);
        return resizedBitmap;
    }
    @Override
    protected void onPause(){
        super.onPause();
        releaseMediaRecorder();
        releaseCamera();
        closeDriver();
    }

    private void releaseMediaRecorder() {mCamera.lock();}

    private void releaseCamera(){
        if(mCamera!=null){
            mCamera.release();
            mCamera= null;
        }
    }
    @Override
    protected void onResume(){
        if(openDriver("/dev/sm9s5422_led")<0){
            Toast.makeText(MainActivity.this, "Driver open Failed", Toast.LENGTH_SHORT).show();
        }
        super.onResume();
    }
}